Zhuoqun Liang
c6liangz
jessy.liang@mail.utoronto.ca


The following requests are supported:

/articles
/authors
/urls
/tags
/details
/details/YOUR_INDEX_HERE
/images
/date
/date/YYYY
/date/YYYY-MM
/date/YYYY-MM-DD

Append these requests to 127.0.0.1:8080 in the URL,
e.g. 127.0.0.1:8080/articles to see what the API returns
for that request. More details available on front-end.